# FootballLinksMVP — Phone + Android TV + Remote Links

This build supports both Android phones and Android TV / Google TV.

## Automatic remote link updates

The app reads `links.json` from the GitHub repository and refreshes it:
- immediately when the app starts;
- automatically every 5 minutes while the app is open;
- manually with the refresh button.

When `links.json` is changed on the server/repository, the app picks up the new URLs on its next refresh without requiring a new APK.

Example link object:

```json
{
  "label": "Official broadcaster",
  "url": "https://example.com/",
  "enabled": true
}
```

Only publish URLs that you are authorized to distribute.

## Important limitation

An APK cannot magically know that a third-party website changed its URL. The remote `links.json` (or a backend that generates it) must be updated when a source URL changes. This app is prepared for that architecture.

## Android TV

The manifest declares Android TV / Leanback support and disables the touchscreen requirement. Interactive controls are focusable for remote/D-pad navigation.

## Build

Open the project in Android Studio or use the included GitHub Actions workflow. The workflow builds `app-debug.apk` and uploads it as an artifact.
