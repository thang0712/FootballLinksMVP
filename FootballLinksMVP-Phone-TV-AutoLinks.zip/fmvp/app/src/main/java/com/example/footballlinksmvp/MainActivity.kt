package com.example.footballlinksmvp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/**
 * Remote data model. Only URLs that you are authorized to publish should be put in links.json.
 */
data class Match(
    val league: String,
    val home: String,
    val away: String,
    val time: String,
    val links: List<Pair<String, String>>
)

private const val REMOTE_DATA_URL =
    "https://raw.githubusercontent.com/thang0712/FootballLinksMVP/main/fmvp/links.json"

// The app refreshes this remote manifest every 5 minutes while it is open.
private const val AUTO_REFRESH_MS = 5 * 60 * 1000L

private val sampleMatches = listOf(
    Match("Premier League", "Arsenal", "Chelsea", "20:00", emptyList()),
    Match("La Liga", "Barcelona", "Sevilla", "22:30", emptyList()),
    Match("Champions League", "Inter", "Real Madrid", "02:00", emptyList())
)

private suspend fun fetchMatches(): List<Match> = withContext(Dispatchers.IO) {
    val connection = (URL("$REMOTE_DATA_URL?t=${System.currentTimeMillis()}").openConnection()
            as HttpURLConnection)
    connection.requestMethod = "GET"
    connection.connectTimeout = 8000
    connection.readTimeout = 8000
    connection.useCaches = false
    connection.setRequestProperty("Cache-Control", "no-cache, no-store")
    connection.setRequestProperty("Pragma", "no-cache")

    try {
        if (connection.responseCode !in 200..299) {
            throw IllegalStateException("HTTP ${connection.responseCode}")
        }

        val json = connection.inputStream.bufferedReader().use { it.readText() }
        val array = JSONArray(json)

        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val linksJson = item.optJSONArray("links") ?: JSONArray()
                val links = buildList {
                    for (j in 0 until linksJson.length()) {
                        val link = linksJson.getJSONObject(j)
                        val label = link.optString("label").trim()
                        val url = link.optString("url").trim()
                        val enabled = link.optBoolean("enabled", true)
                        if (enabled && label.isNotBlank() &&
                            (url.startsWith("https://") || url.startsWith("http://"))) {
                            add(label to url)
                        }
                    }
                }

                val home = item.optString("home").trim()
                val away = item.optString("away").trim()
                if (home.isNotBlank() && away.isNotBlank()) {
                    add(
                        Match(
                            league = item.optString("league", "Khác"),
                            home = home,
                            away = away,
                            time = item.optString("time", "--:--"),
                            links = links
                        )
                    )
                }
            }
        }
    } finally {
        connection.disconnect()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FootballLinksApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FootballLinksApp() {
    var selectedLeague by remember { mutableStateOf("Tất cả") }
    var matches by remember { mutableStateOf(sampleMatches) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var lastUpdated by remember { mutableStateOf<String?>(null) }
    var refreshKey by remember { mutableIntStateOf(0) }

    suspend fun refresh() {
        isLoading = true
        error = null
        try {
            val remote = fetchMatches()
            if (remote.isNotEmpty()) {
                matches = remote
                lastUpdated = java.text.SimpleDateFormat(
                    "HH:mm:ss dd/MM/yyyy",
                    java.util.Locale.getDefault()
                ).format(java.util.Date())
            } else {
                error = "Server chưa có trận đấu."
            }
        } catch (_: Exception) {
            error = "Không tải được dữ liệu mới. Đang giữ dữ liệu hiện tại."
        } finally {
            isLoading = false
        }
    }

    // Initial refresh + automatic polling while the app is visible.
    LaunchedEffect(Unit) {
        refresh()
        while (true) {
            delay(AUTO_REFRESH_MS)
            refresh()
        }
    }

    // Manual refresh button.
    LaunchedEffect(refreshKey) {
        if (refreshKey > 0) refresh()
    }

    val leagues = listOf("Tất cả") + matches.map { it.league }.distinct()
    val filteredMatches = matches.filter {
        selectedLeague == "Tất cả" || it.league == selectedLeague
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SportsSoccer, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Football Links", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { refreshKey++ },
                        enabled = !isLoading,
                        modifier = Modifier.focusable()
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Cập nhật")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Text(
                "Lịch thi đấu & link xem hợp pháp",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            lastUpdated?.let {
                Text(
                    "Tự cập nhật: $it · kiểm tra lại mỗi 5 phút",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            if (isLoading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
            }

            error?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                leagues.forEach { league ->
                    FilterChip(
                        selected = selectedLeague == league,
                        onClick = { selectedLeague = league },
                        label = { Text(league) },
                        modifier = Modifier.focusable()
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(filteredMatches) { match ->
                    MatchCard(match)
                }
            }
        }
    }
}

@Composable
fun MatchCard(match: Match) {
    val context = LocalContext.current
    Card(
        Modifier
            .fillMaxWidth()
            .focusable()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(match.league, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(match.home, fontWeight = FontWeight.SemiBold)
                    Text("vs")
                    Text(match.away, fontWeight = FontWeight.SemiBold)
                }
                Text(match.time, style = MaterialTheme.typography.titleLarge)
            }

            Spacer(Modifier.height(12.dp))
            if (match.links.isNotEmpty()) {
                match.links.forEach { (label, url) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                runCatching {
                                    context.startActivity(
                                        Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                    )
                                }
                            }
                            .focusable()
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Link, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(label, color = MaterialTheme.colorScheme.primary)
                    }
                }
            } else {
                Text(
                    "Chưa có link xem hợp pháp",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
